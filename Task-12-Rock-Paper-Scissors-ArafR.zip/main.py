import random

#Initialize global variables
my_wins = 0
bot_wins = 0
ties = 0
game_over = False

def play_rps(): 
  """Simulates one round of rock-paper-scissors.
  
  First, it prompts the user to enter "rock", "paper", or "scissors". If the user enters "quit", the game ends (game_over becomes True). If the user enters anything else, it prompts them again. 
  
  If the user didn't quit, the bot is assigned "rock", "paper", or "scissors" at random.

  Then, it displays the user's move and the bot's move and says who won the round. The three global variables that keep track of the score are updated."""

  #Declare global variables
  global my_wins, bot_wins, ties, game_over

  user_choice = input("Enter 'rock', 'paper', or 'scissors':")

  if user_choice == "quit":
    game_over = True
    print("Okay, bye.") 
    return

  #Ask for input until a valid choice is given
  while user_choice not in ["rock", "paper", "scissors"]:
    user_choice = input("Enter 'rock', 'paper', or 'scissors':")

  #Bot makes its choice
  bot_choice = random.choice(["rock", "paper", "scissors"])
  print('You chose', user_choice + '.')
  print('Bot chose', bot_choice + '.')

  #Results in case of a tie
  if user_choice == bot_choice:
    ties += 1
    print("It's a tie!")

  #Decision tree to determine the game results
  elif (user_choice == "rock" and bot_choice == "scissors") or \
       (user_choice == "scissors" and bot_choice == "paper") or \
       (user_choice == "paper" and bot_choice == "rock"):
         
    my_wins += 1
    print("You win!")
         
  else:
    bot_wins += 1
    print("Bot wins!")
  
  display_score()
  play_rps()

def display_score():
  
    """Displays the score in the following format:
  My wins: _
  Bot's wins: _
  Ties: _
  """
    print('My wins:', my_wins)
    print("Bot's wins:", bot_wins)
    print('Ties:', ties)

while not game_over:
  display_score()
  play_rps()
