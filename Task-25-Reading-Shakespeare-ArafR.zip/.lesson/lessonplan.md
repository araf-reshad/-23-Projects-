## Lesson Plan  

Students will watch the videos and skim the notes before beginning this task.

Students will be self-directing their learning. Your role is to faciliate their learning by circulating the classroom and regualarly checking in on them. Focus your efforts on helping students who are struggling the most.

## Specific Expectations

A1.1 Use constants and **variables**, including **integers**, floating points, **strings**, correctly in computer programs.

A1.3 Use **assignment statements** correctly with both **arithmetic** and **string expressions** in computer programs.

A1.4 Demonstrate the ability to use **Boolean operators** (e.g., AND, OR, NOT), **comparison operators** (i.e., equal to, not equal to, greater than, less than, greater than or equal to, less than or equal to), **arithmetic operators** (e.g., addition, subtraction, multiplication, division, exponentiation, parentheses), and order of operations correctly in computer programs.

A1.5 Describe the structure of one-dimensional arrays and related concepts, including **elements**, indexes, and **bounds**.

A1.6 Write programs that **declare**, **initialize**, **modify**, and **access one-dimensional arrays**.

A2.2 Use **sequence**, **selection**, and **repetition control** structures to create programming solutions.

A2.3 Write algorithms with **nested structures** (e.g., to count elements in an array, calculate a total, find highest or lowest value, or perform a linear search).

A3.1 Demonstrate the ability to use **existing sub-programs** (e.g., random number generator, substring, absolute value) within computer programs.

A3.2 Write subprograms (e.g., **functions**, **procedures**) that use parameter passing and appropriate **variable scope** (e.g., local, global), to perform tasks within programs.

A4.1 Demonstrate the ability to identify and correct **syntax**, **logic**, and **run-time** errors in computer programs.

A4.2 Use workplace and professional conventions (e.g., **naming**, **indenting**, **commenting**) correctly to write **programs** and **internal documentation**.

A4.3 Demonstrate the ability to **interpret error messages** displayed by programming tools (e.g., compiler, debugging tool), at different times during the software development process (e.g., writing, compilation, testing).

A4.4 Use a **tracing technique** to understand program flow and to **identify and correct logic and run-time errors** in computer programs.

A4.5 Demonstrate the ability to validate a program using a **full range of test cases**.

B1.1 Use **various problem-solving strategies** (e.g., stepwise refinement, divide and conquer, working backwards, examples, extreme cases, tables and charts, trial and error) when solving different types of problems.

B1.2 Demonstrate the ability to **solve problems independently** and as part of a team.

B1.3 Use the **input-process-output model** to solve problems.

B2.1 Design programs from a **program template** or skeleton (e.g., teacher-supplied skeleton, Help facility code snippet).

B2.3 Apply the principle of modularity to design reusable code (e.g., **subprograms**, classes) in computer programs.

B3.1 Design **simple algorithms** (e.g., add data to a sorted array, delete a datum from the middle of an array) according to specifications.

B3.3 Design algorithms to **detect**, **intercept**, and **handle exceptions** (e.g., division by zero, roots of negatives).

B4.4 Use a **test plan** to test programs (i.e., identify test scenarios, identify suitable input data, calculate expected outcomes, record actual outcomes, and conclude ‘pass’ or ‘fail’) by comparing expected to actual outcomes.

B4.5 Use a variety of methods to debug programs (e.g., **manual code tracing**, **extra code to output the state of variables**).

C3.1 Demonstrate an understanding of an integrated software development environment and its main components (e.g., **source code editor**, compiler, debugger).

C3.2 Work independently, using **support documentation** (e.g., IDE Help, tutorials, websites, user manuals), to design and write functioning computer programs.
