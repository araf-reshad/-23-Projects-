## Before Starting This Task

**It's recommended that you only begin this task if you have already submitted Task #21** It's okay if you are waiting for it to be marked.

Choose between watching all the videos or reading all of the notes.

* Pygame Basics ([video](https://www.youtube.com/watch?v=Vmm7BUdEcLk&list=PLVD25niNi0BlwZxjcVF6-vcOdAicWlRjC)|[note](https://github.com/Kitchener-Waterloo-Collegiate-and-VS/ICS3U/blob/main/Unit%203/3.11%20Pygame%20Basics.md))
* Colours and Shapes ([video](https://www.youtube.com/watch?v=ro5BSgWBtag&list=PLVD25niNi0BlwZxjcVF6-vcOdAicWlRjC)|[note](https://github.com/Kitchener-Waterloo-Collegiate-and-VS/ICS3U/blob/main/Unit%203/3.12%20Colours%20and%20Shapes%20in%20Pygame.md))

## Instructions

Write a Pygame program that displays the flag of one of these countries:

* Republic of the Congo
* Guyana
* South Africa
* Tanzania
* Trinidad and Tobago

Search online to find or calculate:
* the flag's dimensions
* exact RGB or hexadecimal values of the colours on the flag
* exact coordinates of each of the individual shapes on the flag

## Criteria
* Your program shows a drawing of a flag of your choice from the 5 options
* The title of the window is updated to say "Flag of ___"
* The flag's size, colours, and shapes are accurate
* The program includes *at least one (1)* helpful line comment

&nbsp;&nbsp;

When these criteria are met and you answer the questions in **sources.md**, you may submit this assignment.

If you submit this task without meeting these criteria, you will be asked to redo it and resubmit it.

## main.py

Here is the original code in **main.py** for reference:

```python
import pygame as pg

pg.init()
WIDTH = 200 # Change this dimension 
HEIGHT = 200 # Change this dimension

screen = pg.display.set_mode((WIDTH, HEIGHT))

# What goes here?

while True:
  pg.display.update()
```
